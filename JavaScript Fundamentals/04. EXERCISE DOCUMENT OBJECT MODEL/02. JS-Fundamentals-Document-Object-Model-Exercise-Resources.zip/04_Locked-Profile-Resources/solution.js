function solve() {
   // TODO:
} 