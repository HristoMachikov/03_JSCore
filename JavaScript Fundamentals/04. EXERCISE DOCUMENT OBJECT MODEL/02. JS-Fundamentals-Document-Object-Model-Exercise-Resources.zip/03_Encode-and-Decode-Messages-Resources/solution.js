function solve() {
	// TODO:
}