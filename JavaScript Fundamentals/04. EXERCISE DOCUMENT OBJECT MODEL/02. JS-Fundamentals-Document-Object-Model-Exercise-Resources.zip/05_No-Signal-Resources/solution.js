function solve() {
	// TODO: 
}