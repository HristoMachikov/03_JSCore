function solve() {
    // TODO:
}