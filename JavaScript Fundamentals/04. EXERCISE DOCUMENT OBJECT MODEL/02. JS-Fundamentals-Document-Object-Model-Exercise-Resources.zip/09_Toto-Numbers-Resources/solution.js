function solve() {
	//TODO: 
}