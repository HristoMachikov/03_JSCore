function solve() {
    //TODO: 
}